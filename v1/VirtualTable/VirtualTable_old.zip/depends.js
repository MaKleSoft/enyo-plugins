enyo.depends(
	"VirtualTable.css",
	"VirtualTable.js",
	"VirtualTableExample.js"
);