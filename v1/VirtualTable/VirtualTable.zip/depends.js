enyo.depends(
	"VirtualTable.css",
	"BasicVirtualTable.js",
	"VirtualTable.js",
	"ScrollingVirtualTable.js",
	"VirtualTableExample.js",
	"ScrollingVirtualTableExample.js"
);